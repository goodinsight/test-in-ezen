package kr.co.dong.DAO;

import org.springframework.stereotype.Repository;

import kr.co.dong.DTO.UserfavoriteDTO;
@Repository
public interface UserfavoriteDAO {
	   public int favCheck(int uf_number);
	   public void favAdd(UserfavoriteDTO dto);
	   public void favDelete(int uf_number);
}
