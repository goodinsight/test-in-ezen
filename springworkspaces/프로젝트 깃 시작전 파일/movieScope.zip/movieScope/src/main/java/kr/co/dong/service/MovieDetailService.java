package kr.co.dong.service;

import org.springframework.stereotype.Service;

import kr.co.dong.VO.MovieVO;
@Service
public interface MovieDetailService {
	public MovieVO movieDetail(int m_number);
}
