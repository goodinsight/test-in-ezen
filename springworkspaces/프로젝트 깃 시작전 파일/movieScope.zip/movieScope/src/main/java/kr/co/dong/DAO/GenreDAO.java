package kr.co.dong.DAO;

import java.util.List;

public interface GenreDAO {
	public String search(int m_number);
	public List<Integer> searchMovie(String m_genre);
}
