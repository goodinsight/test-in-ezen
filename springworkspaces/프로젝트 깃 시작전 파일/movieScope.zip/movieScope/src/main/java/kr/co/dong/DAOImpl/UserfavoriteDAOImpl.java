package kr.co.dong.DAOImpl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import kr.co.dong.DAO.UserfavoriteDAO;
import kr.co.dong.DTO.UserfavoriteDTO;

public class UserfavoriteDAOImpl implements UserfavoriteDAO{

	@Autowired
	SqlSession sqlSession;
	private final static String namespace = "kr.co.dong.userfavoriteMapper";
	
	@Override
	public int favCheck(int uf_number) {
		// TODO Auto-generated method stub
		return sqlSession.selectOne(namespace + ".favCheck", uf_number);
	}

	@Override
	public void favAdd(UserfavoriteDTO dto) {
		// TODO Auto-generated method stub
		sqlSession.insert(namespace + ".favAdd", dto);
	}

	@Override
	public void favDelete(int uf_number) {
		// TODO Auto-generated method stub
		sqlSession.delete(namespace + ".favDelete", uf_number); 
		
	}
}
