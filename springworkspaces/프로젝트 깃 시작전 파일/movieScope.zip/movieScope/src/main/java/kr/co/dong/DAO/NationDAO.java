package kr.co.dong.DAO;

import java.util.List;

public interface NationDAO {
	public String search(int m_number);
	public List<Integer> searchMovie(String m_nation);
}
