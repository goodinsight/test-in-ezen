package kr.co.dong.serviceImpl;

import kr.co.dong.DAO.AgeDAO;
import kr.co.dong.DAO.GenreDAO;
import kr.co.dong.DAO.MovieDAO;
import kr.co.dong.DAO.NationDAO;import kr.co.dong.DAOImpl.GenreDAOImpl;
import kr.co.dong.DTO.MovieDTO;
import kr.co.dong.VO.MovieVO;
import kr.co.dong.service.MovieDetailService;

public class MovieDetailServiceImpl implements MovieDetailService{

	MovieDAO moviedao;
	AgeDAO agedao;
	GenreDAO genredao;
	NationDAO nationdao;
	
	@Override
	public MovieVO movieDetail(int m_number) {
		// TODO Auto-generated method stub
		MovieVO data = null;
		MovieDTO dto = moviedao.detail(m_number);
		data.setM_name(dto.getM_name());
		data.setM_actor(dto.getM_actor());
		data.setM_attendance(dto.getM_attendance());
		data.setM_awards(dto.getM_awards());
		data.setM_director(dto.getM_director());
		data.setM_opening(dto.getM_opening());
		data.setM_reopening(dto.getM_reopening());
		data.setM_runtime(dto.getM_runtime());
		data.setM_genre(genredao.search(m_number));
		data.setM_grade(dto.getM_grade());
		data.setM_nation(nationdao.search(m_number));
		data.setM_age(agedao.search(m_number));
		return data;
	}
	
}
