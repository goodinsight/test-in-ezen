package kr.co.dong.DAO;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import kr.co.dong.DTO.UserDTO;
@Repository
public interface UserDAO {

	public Map login(Map<String, Object> map);
	
	public List<UserDTO> listAll();
	public UserDTO selectOne(int uno);
	public void insert(UserDTO ud);
	public void update (UserDTO ud);
	public void delete(int uno);
}